//morningf@foxmail.com
var that;
var ccFile = require('../../utils/calendar-converter.js')
var calendarConverter = new ccFile.CalendarConverter();
var dayIndex;

//月份天数表
var DAY_OF_MONTH = [
  [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
  [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
];

//判断当前年是否闰年
var isLeapYear = function (year) {
  if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
    return 1;
  else
    return 0;
};

//获取当月有多少天
var getDayCount = function (year, month) {
  return DAY_OF_MONTH[isLeapYear(year)][month];
};

//获取当前索引下是几号
var getDay = function (index) {
  return index - curDayOffset;
};

var pageData = {
  date: "",                //当前日期字符串

  //arr数据是与索引对应的数据信息
  arrIsShow: [],          //是否显示此日期
  arrDays: [],            //关于几号的信息
  arrInfoEx: [],          //农历节假日等扩展信息
  arrInfoExShow: [],      //处理后用于显示的扩展信息

  //选择一天时显示的信息
  detailData: {
    curDay: "",         //detail中显示的日信息
    curInfo1: "",
    curInfo2: "",
  },
  Courses: [],//课表传过来的数据包含课表，科目种类及单价
  oneMonthInfo: [],//包含每天科目种类及数量，总收入
  flagShow: 0,
  nummoney: [],
  oneDayCourses: ["", "", "", "", "", "", "", "", "", "", "", ""],
  MoneyInfo: [],//[数学,12节，40元，480元
  saveDEL: [],
  ArrDels: [],
  S: 0,
  ArrDel: []
};
function setMoneyInfo(oneMonthInfo, Courses) {
  var TMoneyInfo = [];
  var SumNum = 0.0;
  for (var i=0;i<Courses.length;i++) {
    console.log("pqq");
    
    for (var j = 0; j < oneMonthInfo.length; j++) {
      
      if (oneMonthInfo[j].length!=0){
        //console.log(Courses[i].kcmc);
        
        for (var k = 0; k < oneMonthInfo[j].length; k++) {
            if (Courses[i].kcmc == oneMonthInfo[j][k].kcmc) {
              console.log(oneMonthInfo[j][k].kcmc);
              SumNum = SumNum + parseFloat(oneMonthInfo[j][k].Num);
            }
        }
      }
    }
    console.log(SumNum);
    

    TMoneyInfo.push({ "km": Courses[i].kcmc, "num": SumNum, "money": Courses[i].money, "sum": parseFloat(Courses[i].money) * parseFloat(SumNum) });
    SumNum = 0.0;
  }
  return (TMoneyInfo);
}
//返回saveDEL
function loadSaveDEL(year, month, ArrDels, saveDEL) {
  var ym = "a"+year + "-" + month;
  var TsaveDEL = {};//object对象
  if (saveDEL.length == 0) { TsaveDEL[ym]=ArrDels; return (TsaveDEL); }
  else {
    for (var p in saveDEL) {//遍历json对象的每个key/value对,p为key
      TsaveDEL = saveDEL;
      if (p == ym) {
        TsaveDEL[p] = ArrDels;
      } else {
        TsaveDEL[ym] = ArrDels;
      }
      return (TsaveDEL);
    }
  }
}
//加载删除 返回arrdels
function loadDEL(year, month, saveDEL) {
  var ym = "a" +year + "-" + month;
  
  if (saveDEL.length == 0) { return ("haveno"); } else {
    for (var p in saveDEL) {//遍历json对象的每个key/value对,p为key
      console.log("p");
      console.log(p);
      console.log(saveDEL);
      if (p == ym) {
        return (saveDEL[p]);
      } else {
        return ("haveno");
      }

    }
  }
}
//检查缓存加载
function check(y, m, d) {
  var timer = setTimeout(function () {
    if (pageData.Courses.length == 0) {
      check(y, m, d);
    }
    else {
      refreshPageData(y, m, d);
    }
  }, 100);

}
//设置当前详细信息的索引，前台的详细信息会被更新
var setCurDetailIndex = function (index) {
  var curEx = pageData.arrInfoEx[index];
  curDay = curEx.sDay - 1;
  pageData.detailData.curDay = curEx.sDay;
  pageData.detailData.curInfo1 = "农历" + curEx.lunarMonth + "月" + curEx.lunarDay;
  pageData.detailData.curInfo2 = curEx.cYear + curEx.lunarYear + "年 " + curEx.cMonth + "月 " + curEx.cDay + "日 " + curEx.lunarFestival;
}
//---------------------------
//一天的课程安排，Courses课表
var getOneDayCousrse = function (week, Courses ) {
  var j = 0;
  var oneDayCourses = ["", "", "", "", "", "", "", "", "", "", "", ""];
  for (var i = 0; i < 84; i++) {
    if (Courses[i].xqj == week) {


      oneDayCourses[j] = Courses[i].kcmc;
      //console.log(pageData.Courses.wlist[i]);
      j++;
    }
  }

  return (oneDayCourses);
}

//统计一天的课时情况
var getOneDayCousrseInfo = function (CoursesMoney, OneDayCourses, delArr) {//delArr[0,0..]0表示删除

  var CourseAndNum = [];
  var Num = 0;
  var tOneDayCourses = OneDayCourses;
  for (var i = 0; i < 12; i++) {
    if (delArr[i] == 0) {
      tOneDayCourses[i] = "";
    }
  }
  for (var i = 0; i < CoursesMoney.length; i++) {
    for (var j = 0; j < tOneDayCourses.length; j++) {
      if (CoursesMoney[i].kcmc == tOneDayCourses[j]) {
        Num++;
      }
    }
    if (Num != 0) {
      CourseAndNum.push({
        "kcmc": CoursesMoney[i].kcmc, "Num": Num, "SumMoney": parseFloat(CoursesMoney[i].money) * parseFloat(Num)
      });
      Num = 0;
    }
  }
  return (CourseAndNum);
};
//--------------------------------

var jsM = function () {
//---计算每天总工资

if (pageData.Courses.length != 0) {
  pageData.nummoney.splice(0, pageData.nummoney.length);
  for (var i = 0; i < 42; i++) {
    var sum = 0;
    for (var j = 0; j < pageData.oneMonthInfo[i].length; j++) {
      sum = sum + pageData.oneMonthInfo[i][j].SumMoney;
    }

    pageData.nummoney.push(sum);
  }
  //计算一个月的工资总和
  pageData.MoneyInfo = setMoneyInfo(pageData.oneMonthInfo, pageData.Courses.CourseMoney);
  //console.log(pageData);
  var M = pageData.MoneyInfo;
  var s = 0;
  for (var i = 0; i < M.length; i++) {
    s = s + M[i].sum;
  }
  pageData.S = s;
  
  
  //console.log(pageData);
  
}
};
//刷新全部数据
var refreshPageData = function (year, month, day) {
  pageData.date = year + '年' + (month + 1) + '月';

  var TArrDels = loadDEL(year, month, pageData.saveDEL);
        console.log("TArrDels");
        console.log(TArrDels);
        if (TArrDels == "haveno") {
          if (pageData.ArrDels.length==0){
          for (var j = 0; j < 42; j++) {//初始化data中数组
            pageData.ArrDels.push([true,true , true, true, true, true, true, true, true, true, true, true]);
          }
          }
        }
        else {
          pageData.ArrDels = TArrDels;
        }
		
		
  var offset = new Date(year, month, 1).getDay();

  for (var i = 0; i < 42; ++i) {
    pageData.arrIsShow[i] = i < offset || i >= getDayCount(year, month) + offset ? false : true;
    pageData.arrDays[i] = i - offset + 1;
    var d = new Date(year, month, i - offset + 1);

    if (pageData.Courses.length != 0) {
      var OneDayCousrseInfo = { "kcmc": "", "Num": "0", "SumMoney": 0 };
      if (pageData.arrIsShow[i] == true) {
        //pageData.Courses.CourseMoney传来的值
        var week = 0;
        if ((i + 1) % 7 == 0) { week = 7; } else { week = (i + 1) % 7; }
        var OneDayCousrse = getOneDayCousrse(week, pageData.Courses.wlist);
        //返回值{"kcmc": , "Num": Num, "SumMoney":} ;
     //console.log(pageData);
        OneDayCousrseInfo = getOneDayCousrseInfo(pageData.Courses.CourseMoney, OneDayCousrse, pageData.ArrDels[i]);//

      }
      pageData.oneMonthInfo[i] = OneDayCousrseInfo;
    }
    else {
      wx.showToast({
        title: '设置课程表及价格',
        duration: 1000,
      });  
    }

    //
    var dEx = calendarConverter.solar2lunar(d);
    pageData.arrInfoEx[i] = dEx;
    if ("" != dEx.lunarFestival) {
      pageData.arrInfoExShow[i] = dEx.lunarFestival;
    }
    else if ("初一" === dEx.lunarDay) {
      pageData.arrInfoExShow[i] = dEx.lunarMonth + "月";
    }
    else {
      pageData.arrInfoExShow[i] = dEx.lunarDay;
    }
  }

  setCurDetailIndex(offset + day);
  
  jsM();//计算每天工资
  that.setData(pageData);
};
var value = wx.getStorageSync('Courses');
var valueDel = wx.getStorageSync('Del');
console.log(valueDel);
//pageData.Courses = value;

//wx.getStorage({
 // key: 'Courses',
 // success: function (res) {

   // pageData.Courses = res.data;
   // console.log(pageData);
  //}
//});

//console.log(pageData.Courses);
var curDate = new Date();
var curMonth = curDate.getMonth();
var curYear = curDate.getFullYear();
var curDay = curDate.getDay();


//refreshPageData(curYear, curMonth, curDay);
//var Courses={}
Page({
  data: pageData,

  onLoad: function (options) {
    that = this;
    pageData.Courses = value;
    pageData.saveDEL=valueDel;
    console.log(pageData.Courses);
    check(curYear, curMonth, curDay);
    refreshPageData(curYear, curMonth, curDay);

  },
onUnload: function () {
	wx.setStorageSync('Del', pageData.saveDEL);

},
  onShow: function () {
    
    console.log('onshow');
    //console.log(pageData);
    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1];  //当前页面
    //console.log(currPage);
    pageData.Courses = currPage.data.Courses;//更新data
    //console.log(pageData.Courses);
    refreshPageData(curYear, curMonth, curDay);

  },
  goKcb: function (e) {
    wx.navigateTo({
      url: '../kcb/kcb'
    });
  },
  goToday: function (e) {
    curDate = new Date();
    curMonth = curDate.getMonth();
    curYear = curDate.getFullYear();
    curDay = curDate.getDay();
    refreshPageData(curYear, curMonth, curDay);
    this.setData(pageData);
  },

  goLastMonth: function (e) {
    if (0 == curMonth) {
      curMonth = 11;
      --curYear;
    }
    else {
      --curMonth;
    }
    refreshPageData(curYear, curMonth, 0);
    this.setData(pageData);
  },

  goNextMonth: function (e) {
    if (11 == curMonth) {
      curMonth = 0;
      ++curYear;
    }
    else {
      ++curMonth;
    }
    refreshPageData(curYear, curMonth, 0);
    this.setData(pageData);
  },
  close: function (e) {//关闭当天课表
    pageData.flagShow = 0;
    this.setData({
      flagShow: pageData.flagShow
    });
  },
  clean: function (e) {
    wx.showToast({
      title: '清除缓存成功，请重新打开',
      duration: 3000,
    });  
    wx.clearStorageSync();
  },
  SetArrDel: function (e) {
    var checkIndex = e.currentTarget.dataset.index;
    //当前选中的取反值
    pageData.ArrDel[checkIndex] = !pageData.ArrDel[checkIndex];

    pageData.ArrDels[dayIndex] = pageData.ArrDel;
    console.log("del");
    
    //console.log(that.data.ArrDel);
    
    pageData.saveDEL = loadSaveDEL(curYear, curMonth, pageData.ArrDels, pageData.saveDEL);
    
    refreshPageData(curYear, curMonth, 0);
    //jsM();
    console.log(pageData);
    //this.setData(pageData);
    var xx = pageData.saveDEL;
    wx.setStorage({
      key: 'Del',
      data: xx,
      success: function (res) {
        }
    });
    
    
    //wx.setStorageSync('Del', pageData.saveDEL);
      },
  selectDay: function (e) {
    dayIndex = e.currentTarget.dataset.dayIndex;
    setCurDetailIndex(e.currentTarget.dataset.dayIndex);
    //console.log(e);
    var week = e.currentTarget.dataset.col;//星期
    
    console.log(week + "--"+dayIndex);

    pageData.oneDayCourses = getOneDayCousrse(week, pageData.Courses.wlist)
    //console.log(pageData.oneMonthInfo);
    
    pageData.ArrDel = pageData.ArrDels[e.currentTarget.dataset.dayIndex]
    for(let j= 0;j < pageData.oneDayCourses.length;j++){
      if (pageData.oneDayCourses[j] == "") { pageData.ArrDel[j]=false;}
    }
    
    //console.log(pageData.ArrDel);
    pageData.flagShow = 1;//显示当天课表
    //console.log(pageData.nummoney);
    console.log(pageData);

    
    this.setData(pageData);

  },

  bindDateChange: function (e) {
    var arr = e.detail.value.split("-");
    refreshPageData(+arr[0], arr[1] - 1, arr[2] - 1);
    this.setData(pageData);
  },

});
