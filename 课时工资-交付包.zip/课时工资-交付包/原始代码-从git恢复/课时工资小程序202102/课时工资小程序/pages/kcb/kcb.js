//index.js
//获取应用实例
var app = getApp()
var SelectTaplist=[];//单击选择多个
var pageData = {
    wlist: []  ,
  addColorArrays: ["#15B1CF", "#20C652", "#D1AA5A", "#FC2F2D", "#0A2A14", "#61BC62", "#5A2EF3", "#E22AED", "#E22AAD"],
  colorArrays: [],
  inputValue: '',
  inputValue2:'',
  CourseMoney: [],//课程名，单价{ "kcmc": cm, "many":"","money":mcm }

}
for (var i = 0; i < 84; i++) {//初始化data中数组
  pageData.wlist.push({ "skjc": Math.floor(i/7)+1, "xqj": i%7+1, "skcd": 1, "kcmc": "", "money": "" });
  pageData.colorArrays.push("#F0FFFF");//表格颜色
}
wx.getStorage({
  key: 'Courses',
  success: function (res) {
    //console.log(res.data);
    pageData = res.data;
  }
})

Page({
  data: pageData,
  onLoad: function () {
    console.log('onLoad')
    this.setData({
      colorArrays: pageData.colorArrays,
      wlist:pageData.wlist
    })
    //this.setData({
      //colorArrays: this.data.colorArrays
    //})
  },
  onUnload: function () {

    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1];  //当前页面
    var prevPage = pages[pages.length - 2]; //上一个页面
    pageData.CourseMoney.splice(0, pageData.CourseMoney.length);
    for(var i=0;i<84;i++){//统计教的学科
      var cm=pageData.wlist[i].kcmc;
      var mcm = pageData.wlist[i].money;
      for(var j=i+1;j<84;j++){
        if(cm==pageData.wlist[j].kcmc){
          break;
        }
        else{
          if(j==83){
            var tcm = { "kcmc": cm, "many":"","money":mcm }
            
            pageData.CourseMoney.push(tcm);
          }
        }
      }
      
      
    };
    wx.setStorageSync('Courses', pageData);
    console.log(pageData.CourseMoney);
    prevPage.setData({ Courses: pageData });
    //

  },
  showCardView: function (e) {
    var TapIndex = e.currentTarget.dataset.index;
    console.log(e);
    //var length =SelectTaplist.length;
    //let length1 = pageData.colorArrays.length;
    pageData.wlist[TapIndex].money = pageData.inputValue2;
    pageData.wlist[TapIndex].kcmc = pageData.inputValue;
    pageData.colorArrays[TapIndex]=pageData.addColorArrays[TapIndex%8]
    //SelectTaplist[length] = TapIndex;
    this.setData({
      ['colorArrays[' + TapIndex + ']']: pageData.addColorArrays[TapIndex % 8],
      ['wlist[' + TapIndex + '].kcmc']: pageData.wlist[TapIndex].kcmc,
      ['wlist[' + TapIndex + '].money']: pageData.wlist[TapIndex].money
      })
    wx.setStorageSync('Courses', pageData)
    
    //console.log(SelectTaplist[length]);
    console.log(pageData);
    console.log(pageData.inputValue);

  },
  bindKeyInput: function (e) {
    pageData.inputValue = e.detail.value
   
  },
  bindKeyInput2: function (e) {
    pageData.inputValue2 = e.detail.value

  },
})
